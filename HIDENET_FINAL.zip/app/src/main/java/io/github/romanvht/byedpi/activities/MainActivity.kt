package io.github.romanvht.byedpi.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import io.github.romanvht.byedpi.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var connected = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        updateStatus()

        binding.statusButtonCard.setOnClickListener {
            connected = !connected
            updateStatus()
        }
    }

    private fun updateStatus() {
        if (connected) {
            binding.statusText.text = "CONNECTED"
        } else {
            binding.statusText.text = "DISCONNECTED"
        }
    }
}