
package io.github.romanvht.byedpi.activities

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import io.github.romanvht.byedpi.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var connected = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        updateStatus()

        binding.root.setOnClickListener {
            connected = !connected
            updateStatus()
        }
    }

    private fun updateStatus() {
        val status = binding.statusText as TextView
        status.text = if (connected) "CONNECTED" else "DISCONNECTED"
    }
}
